javac JustRun.java Mutant.java Var.java Population.java EvolutionAlgorithm.java Mutator.java Selector.java Recombinator.java MutantStorage.java Cholesky.java
java JustRun